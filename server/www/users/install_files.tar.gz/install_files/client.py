########################### AUTHENTICATION LIBRARIES ################################
import urllib
import urllib2
import cookielib
from getpass import *
########################### CODE LIBRARIES ################################
import glob
import os, sys, struct
from time import sleep
import socket
########################### CODE STARTS ################################

USERNAME = ""				# global variable that is specific to each client.

def authen_code():

	cookieJar = cookielib.LWPCookieJar()
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookieJar))

	opener.addheaders = [('User-agent', "MyApplication")]

	url = 'http://web.cse.iitk.ac.in/users/akrsingh/loginproc.php'

	while 1: 
		 username = raw_input("Enter Username: ")
		 password = getpass("Enter Password: ")


		 form = { "username" : username,"password" : password,'login': 'Login'}

		 try:	
			#print 123	 
			encodedForm = urllib.urlencode(form)
			
			page=opener.open(url,encodedForm)
			#encodedForm = urllib.urlencode(form)

			contents = page.read()
			#print page.geturl()
			#print contents
			if 'Authenticated' in contents:
				global USERNAME
				print 'Authenticated!! \n Connecting to the server ...'
				USERNAME = username
				break
			else:
				print 'Please Recheck Username or password'
				continue

		 except:
			print 'Couldnt process! You werent able to sign in\n This may be that server did not respond'	
	
	
	# CODE USING urllib. USER, PASSWORD, ENTER.
	# IN THIS CODE, THE CLIENT WAITS EVEN IF IT DOES NOT HAVE A NET CONNECTION. WHEN NET CONNECTS, IT TRIES TO SEND ITS LOGIN INFO.
	
	
def md5sum(path):	
	##Computing the check sum at one end
	newpath=''
	for i in path:
		if i==" ":
			newpath+='\\'
		newpath+=i
	#	print "as %si %s" % (i,newpath)	
	if path.find(' ')==-1:
		string="md5sum %s" % (newpath)
	else:	
		string = "md5sum %s" % (newpath )
		
	print 'string is',string, newpath	
		
	cmd = os.popen(string,"r")

	while 1:
		line = cmd.readline()
		if not line: break
		return line.split()[0]	

def send_file(client_socket,i):		#i is path of the file
	#i="Sync"+os.path.sep+"sword.mp3"
	#client_socket.sendall("Size")
	#client_socket.sendall(os.path.getsize(i))
	#client_socket.sendall(i)	#was part of simple one file transfer
	
	try:
		size=os.path.getsize(i)
		print "STARTED"
		a = open(i,"rb")
		print "STARTED"
		a = open(i,"rb")
		sent=0;
		reply=''
		client_socket.sendall("Fine.")
		print "fine sent"
		client_socket.recv(10)
		client_socket.settimeout(None)		#As make it wait sufficiently, message WILL arrive from server
		while(1):
			string = a.read()
			print "sending" , len(string)
			sent=client_socket.sendall(string)	# Here, I am sending the 2044 bytes string, with an ack "asdf" before it.	
			while(reply!="##\n"):
				print reply
				reply=client_socket.recv(4)
			if not string:	break
				#sleep(0.4)
		a.close()
		print "FINISHED SENDING", reply	
	except OSError:
		client_socket.sendall("No file. Sorry.")
		print "sorry sent"
		client_socket.recv(10)	

def create_path(data):
	path=os.path.split(data)
	if path[0]:
		if not os.path.exists(path[0]):
			create_path(path[0])
			os.mkdir(path[0])
	

def recv_file(client_socket,data):		#receives files tested
	#data = client_socket.recv(2048)
	#print data
	print "STARTED"
	stat = client_socket.recv(20)
	if (stat=="Fine."):
		client_socket.sendall('OK.')
	elif (stat == "No file. Sorry."):
		client_socket.sendall("NOK.")
		if (os.path.isfile(data)):
			os.remove(data)
		return
	
	client_socket.settimeout(0.1)
	create_path(data)
	a = open(data,"wb")
	while(1):				# looping to get packets.
		try:
			data = client_socket.recv(2048)
			print "Writing data", len(data)
			if not data:
				#client_socket.send("zero recieved.")	# mdchecksum will come here.
			#	print "zr"
				a.close()
				break
			a.write(data)
			client_socket.sendall("wait")
		except socket.timeout:
			print "timing out"
			a.close()
			break		
	a.close()
	client_socket.sendall("##\n")	# mdchecksum will come here.
	print "FINISHED RECEIVING"
			

def recv_data(sock, length):
	data = ''
	sock.settimeout(2)
	try:
		while len(data) < length:
			bytes_read = sock.recv(length - len(data))
			if not bytes_read:
				raise EOFError('socket closed %d bytes into a %d-byte message'
			% (len(data), length))
			data += bytes_read
		return data
	except socket.timeout:
		return data

def recv_size(the_socket):
    #data length is packed into 4 bytes
    total_len=0;total_data=[];size=sys.maxint
    size_data=sock_data='';recv_size=8192
    while total_len<size:
        sock_data=the_socket.recv(recv_size)
        if not total_data:
            if len(sock_data)>4:
                size_data+=sock_data
                size=struct.unpack('>i', size_data[:4])[0]
                recv_size=size
                if recv_size>524288:recv_size=524288
                total_data.append(size_data[4:])
            else:
                size_data+=sock_data
        else:
            total_data.append(sock_data)
        total_len=sum([len(i) for i in total_data ])
    return ''.join(total_data)

def list_files(path, file_array, dir_array):
	pass
	temp = glob.glob(path+"*")				# lists all the files and folderss in the path folder.
	for i in temp:
		if not os.path.isdir(i):
			file_array.append(i)
		else:
			dir_array.append(i+os.path.sep)
			list_files(i+os.path.sep,file_array, dir_array)

def delete_dir(path):
	print "in delete_dir function. Path is:", path
	f=[]
	d=[]
	list_files(path+os.path.sep,f,d)
	for i in f:
		os.remove(i)
	d.sort()
	d.reverse()
	for i in d:
		os.rmdir(i)
	os.rmdir(path)
	print "delete_dir completed!"

def sync_ker_client(client_socket,Path,array):
	print "********** In sync_ker_client ************"
	counter = 0 # counter is 0 if not syncing/just sent file name.
				# when syncing (actual packets being sent), it is set to 1.
	array = (glob.glob(Path+"*"))				# lists all the files and folders in the path folder.
	print array
	#sleep(2)
	
	for i in array:		# taking each file/directory in Path
		x=''
		for j in i:
			if (j!="\\"):	x+=j
			else:	x+= os.path.sep
		if os.path.isdir(i):	# if it's a directory.
			print "sending directory:",i,x
			message=".Directory: " + x + os.path.sep
			print message, len(message)
			client_socket.sendall(message)
			reply=0
			#sleep(1)
			while(not reply):
				reply = client_socket.recv(512)
				#client_socket.send("SENDING ACK")
				#sleep(1)
				print "\n\t\t\t", reply
			if(reply == "Roger!"):
				print "roger recieved by client"
				th = []
				sync_ker_client(client_socket,i+os.path.sep,th)		# recurse inside the directory, base Path is dir's Path.
			elif(reply=='Cut!'):
				print '*******USED********'
				delete_dir(x)
				continue
			else:	
				print "Directory not recognised." , reply
				exit(0)
		else:					# if its a file.
			# Now, send the file. First, its name & address.
			#response=client_socket.recv(4)
			#print "received ack", response
			hashsum=md5sum(x)
			print "sending file:", x,len("File :" + x)
			#sleep(2)
			client_socket.sendall("File :" + x)
			#sleep(2)
			response=0
			while(not response):	
				response=client_socket.recv(4)
				print 'Ack received :', response
				sleep(0.5)
			
			client_socket.sendall(hashsum)
			synced=0
			synced=(int)(client_socket.recv(2))
			print 'Ack received : ', synced
			#reply=client_socket.recv(512)
			#print "reply is ", reply
			if (synced==0 or synced==3):
				send_file(client_socket,i)
			elif (synced==1):
				pass			# do nothing
			elif (synced==2):
				####### for recieving file
				# first send ack.
				# then recv_file
				# then recv ack.
				client_socket.sendall("commence sending")
				recv_file(client_socket,x)
				if not (client_socket.recv(20) == "Thanks."):
							print "error in recieving ack-'Thanks'."
							exit(0)
				####### recieving file ends.
			elif (synced==4):
				print "Removing file:", x
				os.remove(x)
	
	####### end syncing if all the files of the main folder (and hence of all its subfolders) have been completed. :)
	respnse=0
	if Path == "Sync"+os.path.sep:	
		client_socket.sendall("Sync_End in this folder")
		print 'Did I exit'
		'''Wait for a response if server requires sending of files'''
		while 1:
			print 'Did I exit'
			response=client_socket.recv(1024)
			if(response[:3]=="YES"):
				client_socket.sendall("READY")
				print "received ",response
				if not os.path.split(response[4:])[1]:
						create_path(response[4:])
				else:
					recv_file(client_socket,response[4:])
				print "Responded "
			else:
				break	
			
		print response
	
		print "Synced. Now waiting for 20 seconds!"
		sleep(30)	# wait before you sync further!

def main():
		
	#sleep(2)
	authen_code()
	
	# What if the user provided wrong info? It will try to connect forever, as it wont see any socket on the server side?? :/
	# SOLVE ABOVE PROBLEM. 
	# or 
	# FIND SOME CODE IN WHICH THE CLIENT TRIES TO CONNECT FOR 15 SECS, ELSE IT TERMINATES. (MODIFICATION IN BELOW CODE)

	# trying to connect now.
	
	a=['172.27.19.40','172.27.19.39']
	b=[5028,4028]
	
	for i in range(len(a)):		
		client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		Port = b[i]
		client_socket.connect((a[i], Port))
		print "Connection established."
		# connection established.
		
		client_socket.send("Name:"+USERNAME)	# first sends the username and recieves ack.
		print "Username sent:", USERNAME
		data = client_socket.recv(10)	
		if (data == "Ack"):
			print "Ack recieved."
		else:
			print "Problems recieving ack from server."
			exit(0)
		
		print "Will sync endlessly."
		'''
		i="Sync"+os.path.sep+"sword.mp3"	

		send_file(client_socket,i)	

		client_socket.close()'''
		

		
		while(1):	
			# can apply non-blocking scanf, so if a person wants to quit, he just types something in the terminal. Think. :)
			# if ( non-blocking scanf captures anything <or q/Q, depends on implementation> )
			#		client_socket.send('q')
			#		client_socket.close()
			#		break;
			
			try:
				Path = "Sync" + os.path.sep		# This is the user's 'to-sync' directory.
				array = []				# the array that tells all the files or dirs in a dir.

				data = "Lets sync."
				client_socket.send(data)
				data = recv_data(client_socket, 512)
				print data
				if ( data == "Proceed sync." ):
					sync_ker_client(client_socket,Path,array)
				if not data:
					print "Server disconnected. Switching to alternate server"	
					break;	
		
			except:
				print "Server disconnected. Switching to alternate server"	
				break;	


if __name__ == '__main__':
  main()

